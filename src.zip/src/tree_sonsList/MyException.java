package tree_sonsList;

public class MyException extends RuntimeException{
    public MyException(String errorMessage){
        super(errorMessage);
    }
}
