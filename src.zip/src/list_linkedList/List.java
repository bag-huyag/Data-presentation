package list_linkedList;

public class List implements ListInterface {
    private Node head;

    public List(){
        head = null;
    }

    @Override
    public void insert(Data d, Position p) {
        Data c = (Data) d.clone();//fixed

        //empty list
        if (head == null){
            if (p.getNode() == null) {
                head = new Node(c);//fixed
            }
            return;
        }

        //inserting into last elem
        if (p.getNode() == null) {
            Position p1 = new Position(getLast());
            p1.getNode().setNext(new Node(c));//fixed
            return;
        }

        //inserting into head
        if (p.getNode() == head){
            Node temp = head.getNextNode();
            head.setNext(new Node(head.getData()));
            head.getNextNode().setNext(temp);
            head.setData(c);//fixed
            return;
        }

        //insert into other positions
        Position temp = new Position(getPrevious(p));
        if (temp.getNode() != null) {
            if (temp.getNode().getNextNode() == null){
                temp.getNode().getNextNode().setNext(new Node(c));//fixed
            }
            Node temp2 = temp.getNode().getNextNode();
            temp.getNode().setNext(new Node(c));//fixed
            temp.getNode().getNextNode().setNext(temp2);
        }

    }


    @Override
    public Position locate(Data x) {
        if (x == null) return null;
        return new Position(search(x));
    }

    @Override
    public Data retrieve(Position p) throws IncorrectPositionException {
        if (p == null) throw new IncorrectPositionException("no such position in this List");

        if (p.getNode() == head){
            return head.getData();
        }

        Node temp = getPrevious(p);
        if (temp == null) throw new IncorrectPositionException("no such position in this List");
        return p.getNode().getData();
    }

    @Override
    public void delete(Position p) {
        if (p == null || head == null) return;

        //deleting head
        if (p.getNode() == head) {
            head = head.getNextNode();
            return;
        }

        Position temp = new Position(getPrevious(p));
        if (temp.getNode() != null){
            Node tempNode = temp.getNode().getNextNode();
            temp.getNode().setNext(tempNode.getNextNode());
            p.setP(temp.getNode().getNextNode());
        }
    }

    @Override
    public Position next(Position p) throws IncorrectPositionException {
        if (p == null ) throw new IncorrectPositionException("No such position in the list");

        if (p.getNode() == head) return new Position(head.getNextNode());

        Node temp = getPrevious(p);
        if (temp == null) throw new IncorrectPositionException("No such position in the list");
        return new Position(temp.getNextNode().getNextNode());
    }

    @Override
    public Position previous(Position p) throws IncorrectPositionException {
        if (p == null || p.getNode() == head) throw new IncorrectPositionException("No such position in the list");

        Node result = getPrevious(p);
        if (result != null) return new Position(result);
        throw new IncorrectPositionException("No such position in the list");
//        if (p == null && p.getNode() == head) throw new IncorrectPositionException("No such position in the list");
//        Node q = head;
//        Node q2 = null;
//        int i = 0;
//        Node q2 = getPrevious(p);
        //        getPrevious вместо цикла
//        while (q != null && i != p.getX()) {
//            q2 = q;
//            q = q.getNextNode();
//            i++;
//        }
//        if(q2 == null) throw new IncorrectPositionException("No such position in the list");
//        if(i != p.getX()) throw new IncorrectPositionException("No such position in the list");
//        else {
//            /*if (q2 != null)*/ return new Position(p.getNode() - 1);
//        }
        // throw new IncorrectPositionException("No such position in the list");
    }

    @Override
    public Position first() {
        return new Position(head);
    }

    @Override
    public void makeNull() {
        head = null;
    }

    @Override
    public void printList() {
        if (head == null || head.getData() == null){
            System.out.println("The List is empty");
            return;
        }
        Node p = head;
        int i = 1;
        while (p != null){
            System.out.print((i) + ") ");
            p.getData().printData();
            p = p.getNextNode();
            i++;
        }
        System.out.println();
    }

    private Node getPrevious(Position p) {
        Node q = head;
        Node q2 = null;

        while (q != null){
            if (p.getNode() == q) {
                return q2;
            }
            q2 = q;
            q = q.getNextNode();
        }
        return null;
    }

    private Node getLast() {
        Node q = head;
        Node q2 = null;
        while (q != null){
            q2 = q;
            q = q.getNextNode();
        }
        return q2;
    }

    private Node search(Data x){
        Node q = head;
        while (q!=null){
            if (q.getData().equals(x))
                return q;
            q = q.getNextNode();
        }
        return null;
    }


    @Override
    public Position end() {
        return new Position (null);
    }
}
